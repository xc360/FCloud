// 生产环境
// const CONFIG = {
//   url: location.origin,
//   filePath: "",
//   pagePath: "",
//   appId: "xc0019616597",
//   oauthLogin: "https://basic.ccxc.vip/oauth/login"
// };


// 开发环境
const CONFIG = {
  url: location.origin,
  filePath: '', // 本项目后台地址
  pagePath: '', // 页面路径
  appId: 'xc1151605148', // 应用ID
  oauthLogin: 'http://localhost:8811/oauth/login' // 单点登录地址
}

window['basicConfig'] = CONFIG
